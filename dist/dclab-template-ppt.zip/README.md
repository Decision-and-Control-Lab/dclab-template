# Template Presentazione PowerPoint — Decision & Control Lab

Versione PowerPoint del template beamer (`dclab-template-beamer`),
stessa identità grafica: riquadro verde-acqua in alto a destra, righe
orizzontali di intestazione/piè di pagina e loghi PoliBa + D&CLab in
basso a destra su ogni slide.

> ⚠️ **Prima di iniziare, rinomina il file** `main.pptx` (e la cartella
> del progetto, se lo condividi via GitHub o cartella condivisa) in
> qualcosa che identifichi la tua presentazione, ad esempio
> `slide-nomeconvegno-2026.pptx`. Non lavorare mantenendo il nome
> generico del template: rende difficile distinguere la tua versione da
> quella originale e da altre presentazioni.

## Come iniziare

1. Apri `main.pptx` con PowerPoint (o LibreOffice Impress / Google
   Slides — l'aspetto potrebbe variare leggermente rispetto a
   PowerPoint).
2. **Rinomina il file** (vedi sopra), per non sovrascrivere per errore
   il template originale.
3. Modifica la slide iniziale con titolo, sottotitolo (nome/luogo/data
   del convegno), autori, dipartimento e data.

## Slide di esempio

Il file contiene slide di esempio (Indice, Tabelle, Figure, Blocchi,
Codice) che mostrano come impaginare i contenuti più comuni:
sostituiscile con i tuoi, mantenendo lo stesso stile per coerenza.

## Come modificare i loghi

Per aggiungere o cambiare un logo: seleziona l'immagine in basso a
destra su una slide e sostituiscila (trascinando la nuova immagine al
posto della vecchia, mantenendo posizione e dimensioni). Se lo stesso
logo compare su ogni slide, valuta di modificarlo dal "Master slide"
(scheda Visualizza → Schema diapositiva) così da aggiornarlo in un solo
posto invece che su ogni slide singolarmente.

## Aggiungere nuove slide

Per mantenere la stessa identità grafica, **duplica una slide
esistente** (tasto destro sulla slide nel pannello a sinistra →
Duplica) invece di crearne una vuota da zero: eviti di dover
ricostruire loghi, riquadro e righe decorative a mano.

## Problemi comuni

- **Il font non è quello del template**: se apri il file su un
  computer senza i font usati (ad es. Calibri non installato),
  PowerPoint sostituisce automaticamente con un font simile — il
  layout potrebbe spostarsi leggermente. Verifica sempre l'aspetto
  finale sul computer che userai per presentare.
- **Un'immagine appare sfocata**: usa immagini ad alta risoluzione
  (almeno 150-200 dpi alla dimensione finale) invece di ridimensionare
  molto un'immagine piccola.

## Versione LaTeX

Se preferisci lavorare in LaTeX invece che in PowerPoint, usa il
template equivalente `dclab-template-beamer`: più semplice da
mantenere coerente su molte slide e con supporto nativo a formule,
bibliografia e codice sorgente.
